The HamiltonFastMarching library can be used in two ways from Mathematica:

1 - using the MathematicaHFM libraries, compiled from this directory. 
2 - using the FileHFM executables, compiled from the FileHFM directory.

See the examples. (Currently, there are more for usage 2.)