// HamiltonFastMarching - A Fast-Marching solver with adaptive stencils.
// Copyright (C) 2017 Jean-Marie Mirebeau, University Paris-Sud, CNRS, University Paris-Saclay.
// Licence GPU GPL v3 or later, see <http://www.gnu.org/licenses/>. Distributed WITHOUT ANY WARRANTY.

#ifndef DispatchAndRun_h
#define DispatchAndRun_h

#include "JMM_CPPLibs/Macros/String.h"
#include "JMM_CPPLibs/Macros/PPCat.h"

// Saving the model name as a string for future reference
const std::string ModelNameString=STRING(ModelName);

// **** Do we need high dimensional Voronoi reduction ***
#define HighVoronoi_Riemann4                1
#define HighVoronoi_Riemann5                1
#define HighVoronoi_AsymmetricQuadratic4    1

#if PPCAT(HighVoronoi_,ModelName)
#define HighVoronoi
#endif

// **** Which header contains which model ****
// Experimental specializations
#define CurvatureConvex2_ElasticaConvex2           1
#define CurvatureConvex2_ReedsSheppForwardConvex2  1
#define CurvatureConvex2_DubinsConvex2             1


// **** Include the correct header ****
// Experimental specializations
#if PPCAT(CurvatureConvex2_,ModelName)
#include "Specializations/Curvature2.h"
#include "Experimental/PrescribedCurvature2.h"
#include "Experimental/ConvexityCurvature2.h"
using StencilElasticaConvex2_5 = StencilElasticaConvex2<5>;
#define ElasticaConvex2 ElasticaConvex2_5 // Default discretization


// Very experimental specializations
#else
/*
#include "Experimental/ReedsSheppAdaptive2.h"
#include "Experimental/Quaternionic.h"
#include "Experimental/RollingBall.h"
 */
#endif

// ------- Custom invocation, with multiple models.  ---------
#define HFMSpecializationMacro(modelName) \
{ \
using StencilDataType = Stencil ## modelName ;\
using HFMI = StencilDataType::HFMI; \
if(model== #modelName){ \
    io.currentSetter=IO::SetterTag::Compute;\
    StencilDataType stencil; \
    HFMI(io, stencil).Run();\
    io.currentSetter=IO::SetterTag::User; return;} \
}

#ifdef Custom

#include "Experimental/AlignedBillard.h"
#include "Experimental/TTI.h"
#include "Experimental/AsymRander.h"

#endif


template<typename TTraits> struct HFMInterface2 {
    typedef TTraits Traits;
    typedef HamiltonFastMarching<Traits> HFM;
    Redeclare4Types(HFM,ActiveNeighFlagType,StencilDataType,ExtraAlgorithmInterface,GeodesicSolverInterface);
    
    template<typename E, size_t n> using Array = typename Traits::template Array<E,n>;
    template<typename E> using DataSource = typename Traits::template DataSource<E>;
    template<typename E> struct DataSource_Value;
    
    IO & io;
    StencilDataType & stencil;
    HFMInterface2(IO & _io, StencilDataType & _stencil) : io(_io), stencil(_stencil) {}
    //_pStencil(std::move(pStencil)) {};
    virtual void Run(){};
};


void Run(IO & io){

    // ------- Run a single model --------
#ifdef ModelName
    
    if(io.HasField("model")){
        if(io.GetString("model")!=ModelNameString)
            ExceptionMacro("Executable applies to " << ModelNameString
                           << ", not to " << io.GetString("model") << ".");
    }
//    typedef HFMInterface<PPCAT(Traits,ModelName)> HFMI;
    typedef PPCAT(Stencil,ModelName) StencilDataType;
	using HFMI = StencilDataType::HFMI;
    
    io.currentSetter=IO::SetterTag::Compute;
    StencilDataType stencil;
    HFMI(io, stencil).Run();
    io.currentSetter=IO::SetterTag::User;
	
    return;
#endif
    
    // ------- Run one of several models (mostly debug purposes) ------
    const std::string model = io.GetString("model");
#ifdef Custom
// This custom executable is here to let the user choose the adequate combination of (FastMarchingClass, Model) for his/her application.

//	HFMSpecializationMacro(AsymRander2)
//	HFMSpecializationMacro(TTI2)
//	HFMSpecializationMacro(TTI3)
//    HFMSpecializationMacro(IsotropicDiff<2>)
//    HFMSpecializationMacro(RiemannLifted2<Boundary::Closed>)
	
	/*
	 HFMSpecializationMacro(AlignedBillard)
	 */
/*
    {
        typedef HFMInterface<TraitsLagrangian2> HFMI;
        typedef StencilRanderLag2 StencilDataType;
        if(model== "RanderLag2"){
            io.currentSetter=IO::SetterTag::Compute;
            StencilDataType stencil;
            HFMI(io, stencil).Run();
            io.currentSetter=IO::SetterTag::User; return;}
    }
    
    {
        typedef HFMInterface<TraitsLagrangian2> HFMI;
        typedef StencilAsymmetricQuadraticLag2 StencilDataType;
        if(model== "AsymmetricQuadraticLag2"){
            io.currentSetter=IO::SetterTag::Compute;
            StencilDataType stencil;
            HFMI(io, stencil).Run();
            io.currentSetter=IO::SetterTag::User; return;}
    }*/

    
#endif
    
// ------------- Model options ----------
    /*
#ifdef Riemann
    HFMSpecializationMacro(Riemann2);
    HFMSpecializationMacro(Riemann3);
#endif
    
#ifdef Curvature2
    HFMSpecializationMacro(ReedsShepp2);
    HFMSpecializationMacro(ReedsSheppForward2);
    HFMSpecializationMacro(Dubins2);
    HFMSpecializationMacro(Elastica2<5>);
//    HFMSpecializationMacro(Elastica2<9>);
#endif
    
#ifdef Curvature3
    HFMSpecializationMacro(ReedsShepp3)
    HFMSpecializationMacro(ReedsSheppForward3)
#endif
    
#ifdef Isotropic
    HFMSpecializationMacro(Isotropic2)
    HFMSpecializationMacro(Diagonal2)
    HFMSpecializationMacro(Isotropic3)
    HFMSpecializationMacro(Diagonal3)
#endif
    


// ----------- Experimental -----------
 
#ifdef PrescribedCurvature2
    HFMSpecializationMacro(ReedsSheppExt2)
    HFMSpecializationMacro(ReedsSheppForwardExt2)
    HFMSpecializationMacro(DubinsExt2)
    HFMSpecializationMacro(ElasticaExt2<5>)
#endif
    
#ifdef RiemannExtra    
    // Differentiation with riemannian metrics
    HFMSpecializationMacro(RiemannDiff2)
    
    // Continuous differentiation of isotropic metrics
    HFMSpecializationMacro(IsotropicDiff2)
    
    // Lifted riemannian metrics
    HFMSpecializationMacro(RiemannLifted2<Boundary::Closed>)
    HFMSpecializationMacro(RiemannLifted2<Boundary::Periodic>)
    HFMSpecializationMacro(RiemannLifted3)
#endif
    
#ifdef Experimental0
    // Quaternions
    HFMSpecializationMacro(ReedsSheppSO3)
    HFMSpecializationMacro(ReedsSheppForwardSO3)
    
    // Variants of Reeds-Shepp, with adaptive angular resolution, distinct foward/backward/angular speeds
    HFMSpecializationMacro(ReedsSheppAdaptive2)
    HFMSpecializationMacro(ReedsSheppThreeSpeeds2)
#endif


#ifdef Experimental1
    HFMSpecializationMacro(Riemann4)
    HFMSpecializationMacro(Riemann5)
#endif
*/

    ExceptionMacro("Unrecognized model : " << model);
}


#endif /* DispatchAndRun_h */
