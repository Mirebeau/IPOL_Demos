! Important !

MatlabHFM should be compiled from Matlab(R) using the script named "CompileMexHFM.m", in the directory ExampleFiles.
The provided CMakelists.txt should NOT be used. It only serves internally for some debugging purposes.