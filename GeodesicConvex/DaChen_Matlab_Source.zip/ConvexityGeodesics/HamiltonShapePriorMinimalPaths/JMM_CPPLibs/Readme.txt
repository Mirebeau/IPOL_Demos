// Copyright 2017 Jean-Marie Mirebeau, University Paris-Sud, CNRS, University Paris-Saclay
// Distributed WITHOUT ANY WARRANTY. Licensed under the Apache License, Version 2.0, see http://www.apache.org/licenses/LICENSE-2.0

These header only libraries are used in the HamiltonFastMarching project. (Except the MatlabITKInterface.)


 A low dimensional linear program solver, with Copyright (c) 1990 Michael E. Hohmeyer, is included in LinearAlgebra/LinearAlgebra/Implementation/LinProg
