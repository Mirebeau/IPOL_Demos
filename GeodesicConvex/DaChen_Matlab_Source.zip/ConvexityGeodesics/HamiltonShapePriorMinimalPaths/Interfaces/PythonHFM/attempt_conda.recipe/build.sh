$PYTHON conda.recipe/setup.py install
